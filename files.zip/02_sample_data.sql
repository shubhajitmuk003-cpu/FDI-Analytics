-- =============================================================
-- FILE: 02_sample_data.sql
-- PROJECT: Oracle FDI Analytics
-- DESC: DML — Realistic seed data for all tables
-- =============================================================

-- -------------------------
-- COUNTRIES
-- -------------------------
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('USA','United States','Americas','Northern America');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('CHN','China','Asia','Eastern Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('GBR','United Kingdom','Europe','Northern Europe');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('DEU','Germany','Europe','Western Europe');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('JPN','Japan','Asia','Eastern Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('IND','India','Asia','Southern Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('BRA','Brazil','Americas','South America');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('AUS','Australia','Oceania','Australia and New Zealand');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('SGP','Singapore','Asia','South-Eastern Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('ARE','United Arab Emirates','Asia','Western Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('FRA','France','Europe','Western Europe');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('NLD','Netherlands','Europe','Western Europe');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('CAN','Canada','Americas','Northern America');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('KOR','South Korea','Asia','Eastern Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('ZAF','South Africa','Africa','Sub-Saharan Africa');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('MEX','Mexico','Americas','Central America');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('IDN','Indonesia','Asia','South-Eastern Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('SAU','Saudi Arabia','Asia','Western Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('VNM','Vietnam','Asia','South-Eastern Asia');
INSERT INTO COUNTRIES (iso_code, country_name, region, sub_region) VALUES ('NGA','Nigeria','Africa','Sub-Saharan Africa');

-- -------------------------
-- SECTORS
-- -------------------------
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('TECH','Information Technology','Tertiary','Software, hardware, IT services and digital platforms');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('FIN','Financial Services','Tertiary','Banking, insurance, fintech and capital markets');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('MANU','Manufacturing','Secondary','Industrial production and factory operations');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('ENRG','Energy & Utilities','Primary','Oil, gas, renewables and power generation');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('REAL','Real Estate','Tertiary','Commercial and residential property investment');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('HLTH','Healthcare & Pharma','Tertiary','Hospitals, biotech and pharmaceutical R&D');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('AGRI','Agriculture','Primary','Farming, agribusiness and food production');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('TRAN','Transport & Logistics','Tertiary','Ports, airports, roads and freight services');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('TELE','Telecommunications','Tertiary','Mobile, broadband and network infrastructure');
INSERT INTO SECTORS (sector_code, sector_name, sector_group, description) VALUES ('MINE','Mining & Minerals','Primary','Metal ore, coal and mineral extraction');

-- -------------------------
-- INVESTMENT TYPES
-- -------------------------
INSERT INTO INVESTMENT_TYPES (type_code, type_name, description) VALUES ('GF','Greenfield','New facility or project built from scratch in the host country');
INSERT INTO INVESTMENT_TYPES (type_code, type_name, description) VALUES ('MA','Mergers & Acquisitions','Acquisition of or merger with an existing host-country company');
INSERT INTO INVESTMENT_TYPES (type_code, type_name, description) VALUES ('JV','Joint Venture','Shared-ownership enterprise between foreign and domestic investors');
INSERT INTO INVESTMENT_TYPES (type_code, type_name, description) VALUES ('RE','Reinvestment','Reinvestment of earnings by an existing foreign affiliate');
INSERT INTO INVESTMENT_TYPES (type_code, type_name, description) VALUES ('OL','Other Loans','Inter-company debt and other capital flows');

-- -------------------------
-- EXCHANGE RATES (annual avg, approximate)
-- -------------------------
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('IND', 2020, 0.01362);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('IND', 2021, 0.01360);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('IND', 2022, 0.01258);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('IND', 2023, 0.01205);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('CHN', 2020, 0.14500);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('CHN', 2021, 0.15600);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('CHN', 2022, 0.14800);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('CHN', 2023, 0.13900);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('BRA', 2020, 0.19500);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('BRA', 2021, 0.18200);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('BRA', 2022, 0.19800);
INSERT INTO EXCHANGE_RATES (iso_code, rate_year, usd_rate) VALUES ('BRA', 2023, 0.20100);

-- -------------------------
-- FDI_TRANSACTIONS (50+ realistic records)
-- Source -> Destination, Sector, Type, Year, Amount (USD mn), Jobs
-- -------------------------

-- USA investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (1,6, 1,1, 2020,1, 1250.00, 3, 12000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (1,6, 2,2, 2021,2, 3400.50, 5, 8500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (1,7, 3,1, 2021,3, 980.00,  2, 15000,'World Bank');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (1,9, 1,2, 2022,1, 5600.00, 1, 2000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (1,14,1,3, 2022,4, 2100.00, 4, 9500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (1,6, 6,1, 2023,2, 750.00,  2, 4200,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (1,19,3,1, 2023,3, 1820.00, 6, 22000,'World Bank');

-- China investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (2,7, 8,1, 2020,2, 4200.00, 8, 30000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (2,20,4,1, 2020,4, 1900.00, 3, 5000,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (2,17,10,1,2021,1, 3100.00, 5, 9000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (2,6, 3,1, 2021,3, 2750.00, 4, 18000,'World Bank');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (2,15,10,1,2022,2, 6800.00, 2, 12000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (2,7, 9,3, 2022,4, 1450.00, 3, 7500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (2,17,3,1, 2023,1, 3600.00, 7, 25000,'UNCTAD');

-- UK investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (3,6, 2,2, 2020,3, 2300.00, 2, 3500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (3,1, 1,2, 2021,2, 8900.00, 1, 1200,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (3,6, 6,1, 2022,1, 620.00,  2, 4000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (3,8, 4,1, 2023,3, 1150.00, 1, 800,'World Bank');

-- Germany investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (4,6, 3,1, 2020,4, 3100.00, 5, 20000,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (4,2, 3,3, 2021,1, 4500.00, 3, 16000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (4,6, 1,1, 2022,3, 890.00,  2, 6000,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (4,19,3,1, 2023,2, 2200.00, 4, 14000,'World Bank');

-- Japan investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (5,6, 3,3, 2020,2, 1800.00, 3, 12000,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (5,1, 3,2, 2021,4, 7200.00, 1, 2500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (5,9, 3,3, 2022,2, 2600.00, 4, 10000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (5,19,3,1, 2023,1, 3400.00, 5, 18000,'World Bank');

-- Singapore investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (9,6, 2,4, 2020,3, 1100.00, 1, 1500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (9,6, 1,2, 2021,2, 2800.00, 2, 5000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (9,17,8,1, 2022,1, 1350.00, 3, 8000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (9,6, 5,2, 2023,4, 4100.00, 1, 2000,'OECD');

-- UAE investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (10,6,  5,1,2021,3, 3200.00,2, 3000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (10,15, 4,1,2022,2, 5500.00,1, 1200,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (10,20, 8,1,2023,1, 2100.00,3, 7000,'World Bank');

-- Australia investing abroad
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (8,17, 7,1,2021,2, 760.00, 2, 5500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (8,20, 10,1,2022,4,1800.00, 1, 3000,'World Bank');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (8,6, 4,3, 2023,3, 1200.00,2, 2500,'OECD');

-- Netherlands investing
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (12,6, 2,4,2022,3, 980.00, 1, 1100,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (12,7, 9,3,2023,2, 2200.00,3, 6000,'UNCTAD');

-- Canada investing
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (13,6, 6,1,2021,1, 540.00, 2, 3500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (13,7, 4,3,2022,3, 1900.00,3, 4000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (13,6, 1,2,2023,4, 3100.00,1, 1500,'OECD');

-- South Korea investing
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (14,6, 3,1,2021,2, 2100.00,4, 16000,'UNCTAD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (14,17,3,1,2022,4, 1400.00,3, 11000,'World Bank');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (14,19,3,1,2023,3, 1900.00,5, 14000,'UNTAD');

-- France investing
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (11,6, 6,3,2022,1, 670.00, 2, 4500,'OECD');
INSERT INTO FDI_TRANSACTIONS (source_country_id, dest_country_id, sector_id, inv_type_id, txn_year, txn_quarter, amount_usd_mn, num_projects, jobs_created, data_source)
VALUES (11,7, 3,1,2023,2, 1500.00,3, 10000,'World Bank');

COMMIT;

PROMPT Sample data loaded: 20 countries, 10 sectors, 5 investment types, 50+ transactions.
