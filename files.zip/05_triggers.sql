-- =============================================================
-- FILE: 05_triggers.sql
-- PROJECT: Oracle FDI Analytics
-- DESC: Triggers for audit logging and business rules
-- =============================================================


-- =============================================================
-- TRIGGER: TRG_FDI_AUDIT
-- Logs every INSERT / UPDATE / DELETE on FDI_TRANSACTIONS
-- =============================================================
CREATE OR REPLACE TRIGGER TRG_FDI_AUDIT
AFTER INSERT OR UPDATE OR DELETE ON FDI_TRANSACTIONS
FOR EACH ROW
DECLARE
    v_operation   VARCHAR2(10);
    v_old_json    CLOB;
    v_new_json    CLOB;

    -- Helper: build a lightweight JSON string from a row's key fields
    FUNCTION build_json (
        p_txn_id    NUMBER,
        p_src_id    NUMBER,
        p_dst_id    NUMBER,
        p_sec_id    NUMBER,
        p_year      NUMBER,
        p_amount    NUMBER,
        p_jobs      NUMBER
    ) RETURN CLOB IS
    BEGIN
        RETURN  '{'                                         ||
                '"txn_id":'    || p_txn_id                 || ','  ||
                '"src_id":'    || p_src_id                 || ','  ||
                '"dst_id":'    || p_dst_id                 || ','  ||
                '"sector_id":' || p_sec_id                 || ','  ||
                '"year":'      || p_year                   || ','  ||
                '"amount":'    || p_amount                 || ','  ||
                '"jobs":'      || NVL(TO_CHAR(p_jobs),'null') ||
                '}';
    END build_json;
BEGIN
    IF    INSERTING THEN v_operation := 'INSERT';
    ELSIF UPDATING  THEN v_operation := 'UPDATE';
    ELSE                  v_operation := 'DELETE';
    END IF;

    IF NOT INSERTING THEN
        v_old_json := build_json(
            :OLD.txn_id, :OLD.source_country_id, :OLD.dest_country_id,
            :OLD.sector_id, :OLD.txn_year, :OLD.amount_usd_mn, :OLD.jobs_created);
    END IF;

    IF NOT DELETING THEN
        v_new_json := build_json(
            :NEW.txn_id, :NEW.source_country_id, :NEW.dest_country_id,
            :NEW.sector_id, :NEW.txn_year, :NEW.amount_usd_mn, :NEW.jobs_created);
    END IF;

    INSERT INTO FDI_AUDIT_LOG (
        table_name, operation, record_id,
        old_value_json, new_value_json,
        changed_by, changed_at
    ) VALUES (
        'FDI_TRANSACTIONS', v_operation,
        NVL(:NEW.txn_id, :OLD.txn_id),
        v_old_json, v_new_json,
        USER, SYSTIMESTAMP
    );
END TRG_FDI_AUDIT;
/


-- =============================================================
-- TRIGGER: TRG_FDI_UPDATED_AT
-- Automatically refreshes the updated_at timestamp on UPDATE
-- =============================================================
CREATE OR REPLACE TRIGGER TRG_FDI_UPDATED_AT
BEFORE UPDATE ON FDI_TRANSACTIONS
FOR EACH ROW
BEGIN
    :NEW.updated_at := SYSDATE;
END TRG_FDI_UPDATED_AT;
/


-- =============================================================
-- TRIGGER: TRG_FDI_VALIDATE_YEAR
-- Prevents inserting records with a future year > current year
-- =============================================================
CREATE OR REPLACE TRIGGER TRG_FDI_VALIDATE_YEAR
BEFORE INSERT OR UPDATE ON FDI_TRANSACTIONS
FOR EACH ROW
BEGIN
    IF :NEW.txn_year > TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) THEN
        RAISE_APPLICATION_ERROR(
            -20010,
            'Transaction year ' || :NEW.txn_year ||
            ' cannot be in the future. Current year: ' ||
            TO_CHAR(SYSDATE,'YYYY')
        );
    END IF;
END TRG_FDI_VALIDATE_YEAR;
/


-- =============================================================
-- TRIGGER: TRG_COUNTRY_DEACTIVATE
-- When a country is deactivated (is_active='N'), logs a warning
-- via DBMS_OUTPUT and prevents future FDI inserts with that country
-- (checked via separate application logic or this trigger on FDI)
-- =============================================================
CREATE OR REPLACE TRIGGER TRG_COUNTRY_DEACTIVATE
AFTER UPDATE OF is_active ON COUNTRIES
FOR EACH ROW
WHEN (NEW.is_active = 'N' AND OLD.is_active = 'Y')
BEGIN
    DBMS_OUTPUT.PUT_LINE(
        '[WARNING] Country deactivated: ' || :NEW.country_name ||
        ' (' || :NEW.iso_code || ').' ||
        ' Existing FDI records are preserved.'
    );
END TRG_COUNTRY_DEACTIVATE;
/

PROMPT Triggers created successfully.
