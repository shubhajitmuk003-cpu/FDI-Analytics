-- =============================================================
-- FILE: 06_queries.sql
-- PROJECT: Oracle FDI Analytics
-- DESC: Advanced SQL queries demonstrating analytical capability
-- =============================================================

-- ---------------------------------------------------------------
-- Q1: Total FDI by year with YoY growth
-- Uses: LAG window function
-- ---------------------------------------------------------------
SELECT * FROM VW_FDI_BY_YEAR;

-- ---------------------------------------------------------------
-- Q2: Top 10 investing countries (all years)
-- ---------------------------------------------------------------
SELECT investor_country, region, num_deals,
       total_fdi_usd_mn, avg_deal_size, total_jobs_created, fdi_rank
FROM   VW_TOP_INVESTORS
WHERE  fdi_rank <= 10
ORDER  BY fdi_rank;

-- ---------------------------------------------------------------
-- Q3: Top 10 recipient countries (all years)
-- ---------------------------------------------------------------
SELECT recipient_country, region, num_deals,
       total_inbound_usd_mn, avg_deal_size, total_jobs_created, recipient_rank
FROM   VW_TOP_RECIPIENTS
WHERE  recipient_rank <= 10
ORDER  BY recipient_rank;

-- ---------------------------------------------------------------
-- Q4: FDI heatmap — source region → dest region
-- ---------------------------------------------------------------
SELECT
    sc.region                        AS investor_region,
    dc.region                        AS recipient_region,
    COUNT(*)                         AS num_deals,
    ROUND(SUM(t.amount_usd_mn), 0)   AS total_fdi_usd_mn
FROM  FDI_TRANSACTIONS  t
JOIN  COUNTRIES         sc ON sc.country_id = t.source_country_id
JOIN  COUNTRIES         dc ON dc.country_id = t.dest_country_id
GROUP BY sc.region, dc.region
ORDER BY total_fdi_usd_mn DESC;

-- ---------------------------------------------------------------
-- Q5: Rolling 3-year average FDI per country
-- Uses: AVG with windowing clause
-- ---------------------------------------------------------------
SELECT
    sc.country_name,
    t.txn_year,
    ROUND(SUM(t.amount_usd_mn), 2)                             AS annual_fdi,
    ROUND(AVG(SUM(t.amount_usd_mn))
          OVER (PARTITION BY sc.country_name
                ORDER BY t.txn_year
                ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 2) AS rolling_3yr_avg
FROM  FDI_TRANSACTIONS  t
JOIN  COUNTRIES         sc ON sc.country_id = t.source_country_id
GROUP BY sc.country_name, t.txn_year
ORDER BY sc.country_name, t.txn_year;

-- ---------------------------------------------------------------
-- Q6: NTILE quartile buckets — classify deals by size
-- ---------------------------------------------------------------
SELECT
    txn_id,
    sc.country_name  AS investor,
    dc.country_name  AS recipient,
    s.sector_name,
    t.txn_year,
    t.amount_usd_mn,
    NTILE(4) OVER (ORDER BY t.amount_usd_mn)  AS deal_quartile,
    CASE NTILE(4) OVER (ORDER BY t.amount_usd_mn)
        WHEN 1 THEN 'Small  (<25th pctl)'
        WHEN 2 THEN 'Medium (25–50th)'
        WHEN 3 THEN 'Large  (50–75th)'
        WHEN 4 THEN 'Mega   (>75th)'
    END AS deal_category
FROM  FDI_TRANSACTIONS  t
JOIN  COUNTRIES         sc ON sc.country_id = t.source_country_id
JOIN  COUNTRIES         dc ON dc.country_id = t.dest_country_id
JOIN  SECTORS           s  ON s.sector_id   = t.sector_id
ORDER BY t.amount_usd_mn DESC;

-- ---------------------------------------------------------------
-- Q7: Largest deal per country per year (RANK partitioned)
-- ---------------------------------------------------------------
SELECT *
FROM (
    SELECT
        sc.country_name         AS investor,
        dc.country_name         AS recipient,
        s.sector_name,
        it.type_name            AS inv_type,
        t.txn_year,
        t.amount_usd_mn,
        RANK() OVER (
            PARTITION BY t.source_country_id, t.txn_year
            ORDER BY t.amount_usd_mn DESC
        ) AS rnk
    FROM  FDI_TRANSACTIONS  t
    JOIN  COUNTRIES         sc ON sc.country_id = t.source_country_id
    JOIN  COUNTRIES         dc ON dc.country_id = t.dest_country_id
    JOIN  SECTORS           s  ON s.sector_id   = t.sector_id
    JOIN  INVESTMENT_TYPES  it ON it.inv_type_id = t.inv_type_id
)
WHERE rnk = 1
ORDER BY txn_year, amount_usd_mn DESC;

-- ---------------------------------------------------------------
-- Q8: FDI concentration index per destination (Herfindahl-style)
-- How concentrated is inbound FDI in terms of investor countries?
-- ---------------------------------------------------------------
SELECT
    dest_country,
    num_deals,
    total_inbound_usd_mn,
    ROUND(
        SUM(POWER(share_pct, 2))  -- HHI approximation
    , 2)                          AS hhi_concentration
FROM (
    SELECT
        dc.country_name                               AS dest_country,
        sc.country_name                               AS source_country,
        COUNT(*)                                      AS num_deals,
        SUM(t.amount_usd_mn)                          AS fdi,
        SUM(SUM(t.amount_usd_mn)) OVER
            (PARTITION BY dc.country_name)            AS total_inbound_usd_mn,
        ROUND(
            SUM(t.amount_usd_mn) /
            SUM(SUM(t.amount_usd_mn)) OVER
                (PARTITION BY dc.country_name) * 100
        , 2)                                          AS share_pct
    FROM  FDI_TRANSACTIONS t
    JOIN  COUNTRIES dc ON dc.country_id = t.dest_country_id
    JOIN  COUNTRIES sc ON sc.country_id = t.source_country_id
    GROUP BY dc.country_name, sc.country_name
)
GROUP BY dest_country, num_deals, total_inbound_usd_mn
ORDER BY hhi_concentration DESC;

-- ---------------------------------------------------------------
-- Q9: Quarter seasonality — which quarter attracts most FDI?
-- ---------------------------------------------------------------
SELECT
    txn_quarter,
    COUNT(*)                            AS num_deals,
    ROUND(SUM(amount_usd_mn), 2)        AS total_fdi,
    ROUND(AVG(amount_usd_mn), 2)        AS avg_deal,
    ROUND(SUM(amount_usd_mn) /
          SUM(SUM(amount_usd_mn)) OVER () * 100, 2) AS pct_of_total
FROM  FDI_TRANSACTIONS
WHERE txn_quarter IS NOT NULL
GROUP BY txn_quarter
ORDER BY txn_quarter;

-- ---------------------------------------------------------------
-- Q10: Jobs-per-USD-million efficiency by sector
-- ---------------------------------------------------------------
SELECT
    s.sector_name,
    s.sector_group,
    ROUND(SUM(t.amount_usd_mn), 2)                      AS total_fdi_usd_mn,
    NVL(SUM(t.jobs_created), 0)                         AS total_jobs,
    ROUND(NVL(SUM(t.jobs_created), 0) /
          NULLIF(SUM(t.amount_usd_mn), 0), 2)           AS jobs_per_usd_mn,
    RANK() OVER (
        ORDER BY NVL(SUM(t.jobs_created), 0) /
                 NULLIF(SUM(t.amount_usd_mn), 0) DESC
    )                                                   AS job_efficiency_rank
FROM  FDI_TRANSACTIONS  t
JOIN  SECTORS           s ON s.sector_id = t.sector_id
GROUP BY s.sector_name, s.sector_group
ORDER BY jobs_per_usd_mn DESC;

-- ---------------------------------------------------------------
-- Q11: PIVOT — FDI by top sectors across years
-- ---------------------------------------------------------------
SELECT *
FROM (
    SELECT t.txn_year, s.sector_name, t.amount_usd_mn
    FROM   FDI_TRANSACTIONS t
    JOIN   SECTORS          s ON s.sector_id = t.sector_id
)
PIVOT (
    ROUND(SUM(amount_usd_mn), 0)
    FOR sector_name IN (
        'Information Technology'    AS "IT",
        'Financial Services'        AS "Finance",
        'Manufacturing'             AS "Mfg",
        'Energy & Utilities'        AS "Energy",
        'Mining & Minerals'         AS "Mining"
    )
)
ORDER BY txn_year;

-- ---------------------------------------------------------------
-- Q12: Audit log — last 20 changes
-- ---------------------------------------------------------------
SELECT
    audit_id, operation, record_id,
    changed_by,
    TO_CHAR(changed_at, 'YYYY-MM-DD HH24:MI:SS') AS changed_at,
    SUBSTR(new_value_json, 1, 120)               AS new_snapshot
FROM  FDI_AUDIT_LOG
ORDER BY changed_at DESC
FETCH FIRST 20 ROWS ONLY;
