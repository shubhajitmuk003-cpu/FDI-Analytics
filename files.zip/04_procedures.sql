-- =============================================================
-- FILE: 04_procedures.sql
-- PROJECT: Oracle FDI Analytics
-- DESC: PL/SQL Stored Procedures, Functions & Packages
-- =============================================================


-- =============================================================
-- FUNCTION: FN_GET_COUNTRY_ID
-- Returns country_id from an ISO code; raises exception if not found
-- =============================================================
CREATE OR REPLACE FUNCTION FN_GET_COUNTRY_ID(
    p_iso_code IN CHAR
) RETURN NUMBER IS
    v_id COUNTRIES.country_id%TYPE;
BEGIN
    SELECT country_id INTO v_id
    FROM   COUNTRIES
    WHERE  iso_code = UPPER(p_iso_code);
    RETURN v_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Country ISO code not found: ' || p_iso_code);
END FN_GET_COUNTRY_ID;
/


-- =============================================================
-- FUNCTION: FN_FDI_YOY_GROWTH
-- Returns YoY % growth of total FDI for a given year vs prior year
-- =============================================================
CREATE OR REPLACE FUNCTION FN_FDI_YOY_GROWTH(
    p_year IN NUMBER
) RETURN NUMBER IS
    v_curr  NUMBER := 0;
    v_prev  NUMBER := 0;
BEGIN
    SELECT NVL(SUM(amount_usd_mn), 0) INTO v_curr
    FROM   FDI_TRANSACTIONS WHERE txn_year = p_year;

    SELECT NVL(SUM(amount_usd_mn), 0) INTO v_prev
    FROM   FDI_TRANSACTIONS WHERE txn_year = p_year - 1;

    IF v_prev = 0 THEN RETURN NULL; END IF;
    RETURN ROUND((v_curr - v_prev) / v_prev * 100, 2);
END FN_FDI_YOY_GROWTH;
/


-- =============================================================
-- PACKAGE: PKG_FDI_REPORTS
-- Encapsulates all reporting procedures
-- =============================================================
CREATE OR REPLACE PACKAGE PKG_FDI_REPORTS AS

    -- Print a country summary report to DBMS_OUTPUT
    PROCEDURE PRINT_COUNTRY_REPORT(p_iso_code IN CHAR);

    -- Print a year summary report
    PROCEDURE PRINT_YEAR_REPORT(p_year IN NUMBER);

    -- Print sector breakdown for a given year
    PROCEDURE PRINT_SECTOR_REPORT(p_year IN NUMBER);

    -- Bulk recalculate jobs-per-million for all records (update)
    PROCEDURE RECALCULATE_JOB_RATIO;

END PKG_FDI_REPORTS;
/


CREATE OR REPLACE PACKAGE BODY PKG_FDI_REPORTS AS

    -- ----------------------------------------------------------
    -- PROCEDURE: PRINT_COUNTRY_REPORT
    -- ----------------------------------------------------------
    PROCEDURE PRINT_COUNTRY_REPORT(p_iso_code IN CHAR) IS
        v_country_name  COUNTRIES.country_name%TYPE;
        v_total_out     NUMBER;
        v_total_in      NUMBER;
        v_top_dest      COUNTRIES.country_name%TYPE;
        v_top_sector    SECTORS.sector_name%TYPE;

        CURSOR cur_years IS
            SELECT txn_year, SUM(amount_usd_mn) AS fdi_out
            FROM   FDI_TRANSACTIONS t
            JOIN   COUNTRIES c ON c.country_id = t.source_country_id
            WHERE  c.iso_code = UPPER(p_iso_code)
            GROUP  BY txn_year
            ORDER  BY txn_year;
    BEGIN
        SELECT country_name INTO v_country_name
        FROM   COUNTRIES WHERE iso_code = UPPER(p_iso_code);

        SELECT NVL(SUM(t.amount_usd_mn), 0) INTO v_total_out
        FROM   FDI_TRANSACTIONS t
        JOIN   COUNTRIES c ON c.country_id = t.source_country_id
        WHERE  c.iso_code = UPPER(p_iso_code);

        SELECT NVL(SUM(t.amount_usd_mn), 0) INTO v_total_in
        FROM   FDI_TRANSACTIONS t
        JOIN   COUNTRIES c ON c.country_id = t.dest_country_id
        WHERE  c.iso_code = UPPER(p_iso_code);

        BEGIN
            SELECT dc.country_name INTO v_top_dest
            FROM   FDI_TRANSACTIONS t
            JOIN   COUNTRIES sc ON sc.country_id = t.source_country_id
            JOIN   COUNTRIES dc ON dc.country_id = t.dest_country_id
            WHERE  sc.iso_code = UPPER(p_iso_code)
            GROUP  BY dc.country_name
            ORDER  BY SUM(t.amount_usd_mn) DESC
            FETCH  FIRST 1 ROWS ONLY;
        EXCEPTION WHEN NO_DATA_FOUND THEN v_top_dest := 'N/A';
        END;

        BEGIN
            SELECT s.sector_name INTO v_top_sector
            FROM   FDI_TRANSACTIONS t
            JOIN   COUNTRIES sc ON sc.country_id = t.source_country_id
            JOIN   SECTORS   s  ON s.sector_id   = t.sector_id
            WHERE  sc.iso_code = UPPER(p_iso_code)
            GROUP  BY s.sector_name
            ORDER  BY SUM(t.amount_usd_mn) DESC
            FETCH  FIRST 1 ROWS ONLY;
        EXCEPTION WHEN NO_DATA_FOUND THEN v_top_sector := 'N/A';
        END;

        DBMS_OUTPUT.PUT_LINE('=== FDI Country Report: ' || v_country_name || ' ===');
        DBMS_OUTPUT.PUT_LINE('Total FDI Outflows  : USD ' || TO_CHAR(v_total_out,'FM999,999,999.00') || ' mn');
        DBMS_OUTPUT.PUT_LINE('Total FDI Inflows   : USD ' || TO_CHAR(v_total_in, 'FM999,999,999.00') || ' mn');
        DBMS_OUTPUT.PUT_LINE('Top Destination     : ' || v_top_dest);
        DBMS_OUTPUT.PUT_LINE('Top Outbound Sector : ' || v_top_sector);
        DBMS_OUTPUT.PUT_LINE('--- Year-by-Year Outflows ---');

        FOR rec IN cur_years LOOP
            DBMS_OUTPUT.PUT_LINE(
                '  ' || rec.txn_year || '  USD ' ||
                TO_CHAR(rec.fdi_out, 'FM999,999,999.00') || ' mn' ||
                '  (YoY: ' || NVL(TO_CHAR(FN_FDI_YOY_GROWTH(rec.txn_year)),'—') || '%)');
        END LOOP;

        DBMS_OUTPUT.PUT_LINE('========================================');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Country not found: ' || p_iso_code);
    END PRINT_COUNTRY_REPORT;


    -- ----------------------------------------------------------
    -- PROCEDURE: PRINT_YEAR_REPORT
    -- ----------------------------------------------------------
    PROCEDURE PRINT_YEAR_REPORT(p_year IN NUMBER) IS
        v_total     NUMBER;
        v_deals     NUMBER;
        v_jobs      NUMBER;
        v_yoy       NUMBER;

        CURSOR cur_top5 IS
            SELECT sc.country_name, SUM(t.amount_usd_mn) AS fdi
            FROM   FDI_TRANSACTIONS t
            JOIN   COUNTRIES sc ON sc.country_id = t.source_country_id
            WHERE  t.txn_year = p_year
            GROUP  BY sc.country_name
            ORDER  BY SUM(t.amount_usd_mn) DESC
            FETCH  FIRST 5 ROWS ONLY;
    BEGIN
        SELECT NVL(SUM(amount_usd_mn),0),
               COUNT(*),
               NVL(SUM(jobs_created),0)
        INTO   v_total, v_deals, v_jobs
        FROM   FDI_TRANSACTIONS
        WHERE  txn_year = p_year;

        v_yoy := FN_FDI_YOY_GROWTH(p_year);

        DBMS_OUTPUT.PUT_LINE('=== FDI Year Report: ' || p_year || ' ===');
        DBMS_OUTPUT.PUT_LINE('Total FDI     : USD ' || TO_CHAR(v_total,'FM999,999,999.00') || ' mn');
        DBMS_OUTPUT.PUT_LINE('Deals         : ' || v_deals);
        DBMS_OUTPUT.PUT_LINE('Jobs Created  : ' || TO_CHAR(v_jobs,'FM999,999,999'));
        DBMS_OUTPUT.PUT_LINE('YoY Growth    : ' || NVL(TO_CHAR(v_yoy),'N/A') || '%');
        DBMS_OUTPUT.PUT_LINE('--- Top 5 Investors ---');

        FOR rec IN cur_top5 LOOP
            DBMS_OUTPUT.PUT_LINE('  ' || RPAD(rec.country_name,25) ||
                                 'USD ' || TO_CHAR(rec.fdi,'FM999,999,999.00') || ' mn');
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('=========================================');
    END PRINT_YEAR_REPORT;


    -- ----------------------------------------------------------
    -- PROCEDURE: PRINT_SECTOR_REPORT
    -- ----------------------------------------------------------
    PROCEDURE PRINT_SECTOR_REPORT(p_year IN NUMBER) IS
        CURSOR cur_sectors IS
            SELECT s.sector_name, s.sector_group,
                   COUNT(*)                     AS deals,
                   ROUND(SUM(t.amount_usd_mn),2)AS total_fdi,
                   NVL(SUM(t.jobs_created),0)   AS jobs
            FROM   FDI_TRANSACTIONS t
            JOIN   SECTORS s ON s.sector_id = t.sector_id
            WHERE  t.txn_year = p_year
            GROUP  BY s.sector_name, s.sector_group
            ORDER  BY SUM(t.amount_usd_mn) DESC;
    BEGIN
        DBMS_OUTPUT.PUT_LINE('=== Sector FDI Report: ' || p_year || ' ===');
        FOR rec IN cur_sectors LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(rec.sector_name,30) ||
                ' | ' || RPAD(rec.sector_group,12) ||
                ' | Deals: ' || LPAD(rec.deals,3) ||
                ' | USD ' || TO_CHAR(rec.total_fdi,'FM999,999,999.00') || ' mn' ||
                ' | Jobs: ' || TO_CHAR(rec.jobs,'FM999,999,999'));
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('===========================================');
    END PRINT_SECTOR_REPORT;


    -- ----------------------------------------------------------
    -- PROCEDURE: RECALCULATE_JOB_RATIO
    -- Example bulk-update: set jobs to 0 where NULL
    -- (In a real system this would apply a ratio model)
    -- ----------------------------------------------------------
    PROCEDURE RECALCULATE_JOB_RATIO IS
        v_updated NUMBER;
    BEGIN
        UPDATE FDI_TRANSACTIONS
        SET    jobs_created = ROUND(amount_usd_mn * 5, 0),
               updated_at   = SYSDATE
        WHERE  jobs_created IS NULL;

        v_updated := SQL%ROWCOUNT;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Jobs recalculated for ' || v_updated || ' records.');
    END RECALCULATE_JOB_RATIO;

END PKG_FDI_REPORTS;
/

-- =============================================================
-- PROCEDURE: SP_INSERT_FDI_TXN
-- Safe single-transaction insert with validation
-- =============================================================
CREATE OR REPLACE PROCEDURE SP_INSERT_FDI_TXN (
    p_src_iso       IN CHAR,
    p_dst_iso       IN CHAR,
    p_sector_code   IN VARCHAR2,
    p_type_code     IN VARCHAR2,
    p_year          IN NUMBER,
    p_quarter       IN NUMBER   DEFAULT NULL,
    p_amount_usd_mn IN NUMBER,
    p_num_projects  IN NUMBER   DEFAULT 1,
    p_jobs          IN NUMBER   DEFAULT NULL,
    p_notes         IN VARCHAR2 DEFAULT NULL
) IS
    v_src_id    COUNTRIES.country_id%TYPE;
    v_dst_id    COUNTRIES.country_id%TYPE;
    v_sec_id    SECTORS.sector_id%TYPE;
    v_type_id   INVESTMENT_TYPES.inv_type_id%TYPE;
BEGIN
    -- Resolve IDs
    v_src_id := FN_GET_COUNTRY_ID(p_src_iso);
    v_dst_id := FN_GET_COUNTRY_ID(p_dst_iso);

    SELECT sector_id INTO v_sec_id
    FROM   SECTORS WHERE sector_code = UPPER(p_sector_code);

    SELECT inv_type_id INTO v_type_id
    FROM   INVESTMENT_TYPES WHERE type_code = UPPER(p_type_code);

    -- Validate amount
    IF p_amount_usd_mn <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Amount must be positive.');
    END IF;

    -- Insert
    INSERT INTO FDI_TRANSACTIONS (
        source_country_id, dest_country_id,
        sector_id, inv_type_id,
        txn_year, txn_quarter,
        amount_usd_mn, num_projects, jobs_created, notes
    ) VALUES (
        v_src_id, v_dst_id,
        v_sec_id, v_type_id,
        p_year, p_quarter,
        p_amount_usd_mn, p_num_projects, p_jobs, p_notes
    );

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Transaction inserted successfully (ID: ' ||
                          SEQ_FDI_TXN.CURRVAL || ')');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END SP_INSERT_FDI_TXN;
/

PROMPT Procedures and package created successfully.
