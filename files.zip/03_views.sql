-- =============================================================
-- FILE: 03_views.sql
-- PROJECT: Oracle FDI Analytics
-- DESC: Analytical views for reporting and dashboarding
-- =============================================================

-- ---------------------------------------------------------------
-- VIEW 1: VW_FDI_FULL
-- Denormalised view joining all dimensions for easy querying
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW VW_FDI_FULL AS
SELECT
    t.txn_id,
    t.txn_year,
    t.txn_quarter,
    -- Source (Investor) country
    sc.country_name     AS source_country,
    sc.iso_code         AS source_iso,
    sc.region           AS source_region,
    sc.sub_region       AS source_sub_region,
    -- Destination (Recipient) country
    dc.country_name     AS dest_country,
    dc.iso_code         AS dest_iso,
    dc.region           AS dest_region,
    dc.sub_region       AS dest_sub_region,
    -- Sector
    s.sector_name,
    s.sector_code,
    s.sector_group,
    -- Investment type
    it.type_name        AS investment_type,
    it.type_code,
    -- Amounts
    t.amount_usd_mn,
    t.num_projects,
    t.jobs_created,
    t.data_source,
    t.notes
FROM  FDI_TRANSACTIONS  t
JOIN  COUNTRIES         sc ON sc.country_id = t.source_country_id
JOIN  COUNTRIES         dc ON dc.country_id = t.dest_country_id
JOIN  SECTORS           s  ON s.sector_id   = t.sector_id
JOIN  INVESTMENT_TYPES  it ON it.inv_type_id = t.inv_type_id;

COMMENT ON TABLE VW_FDI_FULL IS 'Flat denormalised view of all FDI transactions with descriptive labels';


-- ---------------------------------------------------------------
-- VIEW 2: VW_FDI_BY_YEAR
-- Annual aggregates — total FDI, projects, jobs
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW VW_FDI_BY_YEAR AS
SELECT
    txn_year,
    COUNT(*)                        AS total_deals,
    SUM(num_projects)               AS total_projects,
    ROUND(SUM(amount_usd_mn),2)     AS total_fdi_usd_mn,
    ROUND(AVG(amount_usd_mn),2)     AS avg_deal_size_usd_mn,
    SUM(jobs_created)               AS total_jobs,
    ROUND(SUM(amount_usd_mn) - LAG(SUM(amount_usd_mn))
          OVER (ORDER BY txn_year), 2)                  AS yoy_change_usd_mn,
    ROUND(
        (SUM(amount_usd_mn) - LAG(SUM(amount_usd_mn)) OVER (ORDER BY txn_year))
        / NULLIF(LAG(SUM(amount_usd_mn)) OVER (ORDER BY txn_year), 0) * 100
    , 2)                                                AS yoy_pct_change
FROM FDI_TRANSACTIONS
GROUP BY txn_year
ORDER BY txn_year;

COMMENT ON TABLE VW_FDI_BY_YEAR IS 'Year-over-year FDI trend with growth rates';


-- ---------------------------------------------------------------
-- VIEW 3: VW_TOP_INVESTORS
-- Top investing countries by total FDI outflow
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW VW_TOP_INVESTORS AS
SELECT
    sc.country_name                     AS investor_country,
    sc.region,
    COUNT(*)                            AS num_deals,
    SUM(t.num_projects)                 AS total_projects,
    ROUND(SUM(t.amount_usd_mn), 2)      AS total_fdi_usd_mn,
    ROUND(AVG(t.amount_usd_mn), 2)      AS avg_deal_size,
    SUM(t.jobs_created)                 AS total_jobs_created,
    RANK() OVER (ORDER BY SUM(t.amount_usd_mn) DESC) AS fdi_rank
FROM FDI_TRANSACTIONS   t
JOIN COUNTRIES          sc ON sc.country_id = t.source_country_id
GROUP BY sc.country_name, sc.region;

COMMENT ON TABLE VW_TOP_INVESTORS IS 'Ranking of countries by total FDI outflows';


-- ---------------------------------------------------------------
-- VIEW 4: VW_TOP_RECIPIENTS
-- Top recipient countries by inbound FDI
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW VW_TOP_RECIPIENTS AS
SELECT
    dc.country_name                     AS recipient_country,
    dc.region,
    COUNT(*)                            AS num_deals,
    SUM(t.num_projects)                 AS total_projects,
    ROUND(SUM(t.amount_usd_mn), 2)      AS total_inbound_usd_mn,
    ROUND(AVG(t.amount_usd_mn), 2)      AS avg_deal_size,
    SUM(t.jobs_created)                 AS total_jobs_created,
    RANK() OVER (ORDER BY SUM(t.amount_usd_mn) DESC) AS recipient_rank
FROM FDI_TRANSACTIONS   t
JOIN COUNTRIES          dc ON dc.country_id = t.dest_country_id
GROUP BY dc.country_name, dc.region;

COMMENT ON TABLE VW_TOP_RECIPIENTS IS 'Ranking of countries by total FDI inflows';


-- ---------------------------------------------------------------
-- VIEW 5: VW_FDI_BY_SECTOR
-- FDI breakdown by industry sector
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW VW_FDI_BY_SECTOR AS
SELECT
    s.sector_name,
    s.sector_group,
    COUNT(*)                            AS num_deals,
    ROUND(SUM(t.amount_usd_mn), 2)      AS total_fdi_usd_mn,
    ROUND(AVG(t.amount_usd_mn), 2)      AS avg_deal_size,
    SUM(t.jobs_created)                 AS total_jobs,
    ROUND(
        SUM(t.amount_usd_mn) /
        SUM(SUM(t.amount_usd_mn)) OVER () * 100
    , 2)                                AS pct_of_total,
    RANK() OVER (ORDER BY SUM(t.amount_usd_mn) DESC) AS sector_rank
FROM FDI_TRANSACTIONS   t
JOIN SECTORS            s ON s.sector_id = t.sector_id
GROUP BY s.sector_name, s.sector_group;

COMMENT ON TABLE VW_FDI_BY_SECTOR IS 'FDI distribution across industry sectors with share of total';


-- ---------------------------------------------------------------
-- VIEW 6: VW_FDI_BY_INV_TYPE
-- FDI split by investment mode (Greenfield, M&A, JV…)
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW VW_FDI_BY_INV_TYPE AS
SELECT
    it.type_name                        AS investment_type,
    COUNT(*)                            AS num_deals,
    ROUND(SUM(t.amount_usd_mn), 2)      AS total_fdi_usd_mn,
    ROUND(
        SUM(t.amount_usd_mn) /
        SUM(SUM(t.amount_usd_mn)) OVER () * 100
    , 2)                                AS pct_of_total,
    SUM(t.jobs_created)                 AS total_jobs
FROM FDI_TRANSACTIONS   t
JOIN INVESTMENT_TYPES   it ON it.inv_type_id = t.inv_type_id
GROUP BY it.type_name;

COMMENT ON TABLE VW_FDI_BY_INV_TYPE IS 'FDI by entry mode (Greenfield, M&A, JV, Reinvestment, Other)';


-- ---------------------------------------------------------------
-- VIEW 7: VW_BILATERAL_FDI
-- Country-pair bilateral flows (corridor view)
-- ---------------------------------------------------------------
CREATE OR REPLACE VIEW VW_BILATERAL_FDI AS
SELECT
    sc.country_name                     AS source_country,
    dc.country_name                     AS dest_country,
    sc.region                           AS source_region,
    dc.region                           AS dest_region,
    COUNT(*)                            AS num_deals,
    ROUND(SUM(t.amount_usd_mn), 2)      AS total_fdi_usd_mn,
    SUM(t.jobs_created)                 AS total_jobs,
    MIN(t.txn_year)                     AS first_txn_year,
    MAX(t.txn_year)                     AS latest_txn_year
FROM FDI_TRANSACTIONS   t
JOIN COUNTRIES          sc ON sc.country_id = t.source_country_id
JOIN COUNTRIES          dc ON dc.country_id = t.dest_country_id
GROUP BY sc.country_name, dc.country_name, sc.region, dc.region
ORDER BY total_fdi_usd_mn DESC;

COMMENT ON TABLE VW_BILATERAL_FDI IS 'Bilateral investment corridors between country pairs';

PROMPT Views created successfully.
