# 🌍 Oracle FDI Analytics — Portfolio Project

A full-stack Oracle Database project for tracking, analyzing, and reporting **Foreign Direct Investment (FDI)** flows across countries, sectors, and years.

---

## 📁 Project Structure

```
oracle-fdi-project/
├── sql/
│   ├── 01_schema.sql         → DDL: Tables, constraints, indexes
│   ├── 02_sample_data.sql    → DML: Realistic seed data
│   ├── 03_views.sql          → Analytical views
│   ├── 04_procedures.sql     → Stored procedures & functions
│   ├── 05_triggers.sql       → Audit & business-rule triggers
│   └── 06_queries.sql        → Advanced analytical SQL queries
├── dashboard.html            → Interactive visual dashboard
└── README.md
```

---

## 🗃️ Database Schema Overview

| Table | Description |
|---|---|
| `COUNTRIES` | Country master data (ISO codes, regions) |
| `SECTORS` | Industry/sector classification |
| `INVESTMENT_TYPES` | Greenfield, M&A, Joint Venture, etc. |
| `FDI_TRANSACTIONS` | Core fact table of investment flows |
| `EXCHANGE_RATES` | USD conversion rates by year |
| `FDI_AUDIT_LOG` | Audit trail for data changes |

---

## 🔑 Key Features

- **Normalized schema** (3NF) with referential integrity
- **Analytical Views** for top investors, sector breakdowns, YoY trends
- **Stored Procedures** for bulk reporting and data ingestion
- **Triggers** for audit logging and data validation
- **Window Functions** (RANK, LAG, LEAD, NTILE) for advanced analytics
- **Interactive HTML Dashboard** with charts and KPI cards

---

## 🚀 How to Run

1. Connect to your Oracle DB as a user with CREATE TABLE / CREATE PROCEDURE privileges
2. Execute scripts in order: `01_schema.sql` → `02_sample_data.sql` → `03_views.sql` → `04_procedures.sql` → `05_triggers.sql`
3. Run queries from `06_queries.sql` to explore analytics
4. Open `dashboard.html` in a browser for the visual overview

---

## 🛠️ Technologies

- **Oracle Database 19c / 21c**
- **PL/SQL** — Procedures, Functions, Triggers, Cursors
- **SQL** — DDL, DML, Analytic / Window Functions
- **HTML5 / CSS3 / JavaScript** — Dashboard (Chart.js)

---

## 👤 Author

Built as a portfolio demonstration of Oracle database design, PL/SQL programming, and analytical SQL.
